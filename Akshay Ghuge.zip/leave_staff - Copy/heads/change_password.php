<!DOCTYPE html>
 <head>
  <style>
  body{
  
        background-image:url("../vendors/images/passhod.jpg");
		background-size:100% auto;
       }
    form{
            background:linear-gradient(to top,#ff6600,#ffffff,#ccff00,#006666);
		   width:250px;
		   height:320px;
		   padding:15px;
		   box-shadow:1px 1px 15px blue;
		   margin:auto;
		   }
    label{
	       font-size:20px;
	       }
	span{
	       color:red;
	      }
    input{
	        width:230px;
			height:25px;
			border-radius:5px;
			outline:none;
	       }
	.button{
	        color:white;
            background-color:#00cc33;
			width:150px;
			height:30px;
			padding:5px;
			border-radius:4px;
			font-size:15px;
			}
	 p{
	    font-size:20px;
		color:black;
		}
	 input:hover{
	             border:2px solid blue;
				 }
  </style>
 </head>
  <body><br><br><br><br><br><br><br><br><br><br><br><br>
      <div>
	     <form>
		      <h2 style="text-align:center; color:red;">Create Password</h2>
		      <label>Enter register username</label><span>*</span><br>
              <input type="email" id="ee" name="ee" required autofocus/>
			  <br>	
			  <label>Create new password</label><span>*</span><br>
              <input type="password" id="pass" name="pass" required/>
			  <br>
			  <label>Confirm password</label><span>*</span><br>
              <input type="password" id="pass1" name="pass1" required/>
			  <br><br>
			  <button class="button"><b>Submit</b></button>&nbsp;&nbsp;&nbsp;<a href="http://localhost/leave_staff/" style="color:blue; font-size:20px;">Login</a>
		 </form>
	  </div>
  </body>
</html>
