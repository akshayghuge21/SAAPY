<div class="left-side-bar">
		<div class="brand-logo">
			<a href="index.php">
				<img src="../vendors/images/deskapp-logo-svg.png" alt="" class="dark-logo">
				<h3 style="color:white">ACE Leave</h3>
				<img src="" alt="" class="light-logo">
			</a>
			<div class="close-sidebar" data-toggle="left-sidebar-close">
				<i class="ion-close-round"></i>
			</div>
		</div>
		<div class="menu-block customscroll">
			<div class="sidebar-menu">
				<ul id="accordion-menu">
					<li class="dropdown">
						<a href="index.php" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-house-1"></span><span class="mtext">Dashboard</span>
						</a>
						
					</li>
					<li class="dropdown">
						<a href="javascript:;" class="dropdown-toggle">
							<span class="micon dw dw-apartment"></span><span class="mtext"> Leave </span>
						</a>
						<ul class="submenu">
							<li><a href="apply_leave.php">Apply Leave</a></li>
							<li><a href="leave_history.php">Leave History</a></li>
						</ul>
					</li>

					<li>
						<div class="dropdown-divider"></div>
					</li>
					<li>
						<div class="sidebar-small-cap">Extra</div>
					</li>
					<li>
						<a href="http://www.acenagthana.ac.in/" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-edit-2"></span><span class="mtext">Visit ACE</span>
						</a>
					</li>
					<li>
						<a href="http://localhost/demo/sending-mail-using-php/" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-paper-plane1"></span>
							<span class="mtext">Apply Leave Email</span>
						</a>
					</li>
					<li>
						<a href="http://localhost/demo/Send Email Example.html" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-paper-plane1"></span>
							<span class="mtext">Confirm Leave Email</span>
						</a>
					</li>
					<li>
						<a href="http://localhost/demo/leavesformat.html" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-paper-plane1"></span>
							<span class="mtext">Leaves Format</span>
						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>