<!DOCTYPE html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="Generator" content="EditPlus®">
  <meta name="Author" content="">
  <meta name="Keywords" content="">
  <meta name="Description" content="">
  <title>Document</title>
  <style>
   body{
  
        background-image:url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSRRSo-NKPmR0AE9utvMiIJm5kF8XJO63aVpr3zYK_aG9JIEAqUOMeM8D4Xe2jInklKzfM&usqp=CAU");
		background-size:100% auto;
       }
 </style>
 </head>
 <body>
 <h1 style="color:white;text-align:center;"><u>Leave Management System For ACE Project Developed By SAAPY</u></h1><br>
    <h3 style="color:white; text-align:center">
	   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1)Name: Akshay Vasantrao Ghuge<br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Washim Maharashtra<br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email: ghuge3433@gmail.com<br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mo.no: 9370359959<br><br>
	   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2)Name: Sakshi Dnyaneshwar Lambat<br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wardha Maharashtra<br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email: sakshilambat521@gmail.com<br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mo.no: 7558264411<br><br>
	   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3)Name: Achal Suresh Masram<br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yavatmal Maharashtra<br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email: achalmasram14@gmail.com<br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mo.no: 9067057836<br><br>
	   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4)Name: Yash Rohidas Rathod<br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Yavatmal Maharashtra<br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email: rathodyash164@gmail.com<br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mo.no: 7620071333<br><br>
	   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5)Name: Padmashila Palasram Supare<br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Wardha Maharashtra<br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Email: padmasupare4444@gmail.com<br>
       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mo.no: 7559416814<br><br>
	</h3>
  </body>
</html>
