<div class="left-side-bar">
		<div class="brand-logo">
			<a href="admin_dashboard.php">
				<img src="../vendors/images/deskapp-logo-svg.png" alt="" class="dark-logo">
				<h3 style="color:white">ACE Leave</h3>
				<img src="" alt="" class="light-logo">
			</a>
			<div class="close-sidebar" data-toggle="left-sidebar-close">
				<i class="ion-close-round"></i>
			</div>
		</div>
		<div class="menu-block customscroll">
			<div class="sidebar-menu">
				<ul id="accordion-menu">
					<li class="dropdown">
						<a href="admin_dashboard.php" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-house-1"></span><span class="mtext">Dashboard</span>
						</a>
						
					</li>
					<li>
						<a href="department.php" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-calendar1"></span><span class="mtext">Department</span>
						</a>
					</li>
					<li>
						<a href="leave_type.php" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-calendar1"></span><span class="mtext">Leave Type</span>
						</a>
					</li>
					<li class="dropdown">
						<a href="javascript:;" class="dropdown-toggle">
							<span class="micon dw dw-library"></span><span class="mtext">Staff</span>
						</a>
						<ul class="submenu">
							<li><a href="add_staff.php">New Staff</a></li>
							<li><a href="staff.php">Manage Staff</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="javascript:;" class="dropdown-toggle">
							<span class="micon dw dw-apartment"></span><span class="mtext"> Leave </span>
						</a>
						<ul class="submenu">
							<li><a href="apply_leave.php">Apply Leave</a></li>
							<li><a href="leaves.php">All Leave</a></li>
							<li><a href="pending_leave.php">Pending Leave</a></li>
							<li><a href="approved_leave.php">Approved Leave</a></li>
							<li><a href="rejected_leave.php">Rejected Leave</a></li>
							<li><a href="leave_history.php">Leave History</a></li>
						</ul>
					</li>

					<li>
						<div class="dropdown-divider"></div>
					</li>
					<li>
						<div class="sidebar-small-cap">Extra</div>
					</li>
					<li>
						<a href="http://www.acenagthana.ac.in/" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-edit-2"></span><span class="mtext">Visit Us</span>
						</a>
					</li>
					<li>
						<a href="http://localhost/demo/sending-mail-using-php/" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-paper-plane1"></span>
							<span class="mtext">Apply Leave Email</span>
						</a>
					</li>
					<li>
						<a href="http://localhost/demo/Send Email Example.html" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-paper-plane1"></span>
							<span class="mtext">Confirm Leave Email</span>
						</a>
					</li>
		            <li>
						<a href="http://localhost/demo/leavesformat.html" class="dropdown-toggle no-arrow">
							<span class="micon dw dw-paper-plane1"></span>
							<span class="mtext">Leaves Format</span>
						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>