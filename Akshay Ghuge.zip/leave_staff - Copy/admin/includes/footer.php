<div class="footer-wrap pd-20 mb-20 card-box">
				ACE Leave System <a href="akshay info.php" target="_blank"><span><strong>developed by </span> SAAPY</strong></a>
			</div>